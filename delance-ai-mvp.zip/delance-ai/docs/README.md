# Project notes

This folder holds planning notes for DELANCE.AI.

- `concept.md` (to write): the problem statement and vision.
- `architecture.md` (to write): how capabilities, agents, and permissions fit together.
- `decisions.md` (to write): log of decisions, including the license choice.
