# Contributing to DELANCE.AI

Thanks for helping shape DELANCE.AI. The project is at the concept stage, so the most useful contributions right now are ideas, feedback, and careful review.

## Ways to contribute

- Open an issue to propose a feature, a capability format change, or a copy correction.
- Review the capability draft in `capabilities/` and suggest improvements.
- Improve the landing page in `src/` (accessibility, performance, and browser compatibility fixes are welcome).

## Guidelines

1. Keep changes focused. One topic per pull request.
2. The landing page has no build step. Keep dependencies out of `src/` unless there is a strong reason.
3. Preserve accessibility: keyboard navigation, focus states, and `prefers-reduced-motion` support.
4. Do not present planned features as available. Mark anything unbuilt as planned.

## Before opening a pull request

- Test the page in at least two desktop browsers and one mobile viewport.
- Check that the mobile menu opens, closes, and that links scroll correctly.
- Describe what changed and why.

## License

Contributions will be made under the license that the project adopts. The license is still to be announced.
