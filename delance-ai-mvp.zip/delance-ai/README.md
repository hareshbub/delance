# DELANCE.AI

**Delegate Freelancing. Your expertise. Amplified by AI.**

DELANCE.AI is an open-source platform concept for independent professionals to package their expertise into reusable AI capabilities, delegate execution to AI agents, and collaborate with other specialists on bigger projects.

> **Status: concept stage.** This repository contains the MVP landing page. The platform features described on the page are planned directions, not currently available functionality.

## What's in this repository

```
delance-ai/
├── src/                      # MVP landing page (static, no build step)
│   ├── index.html
│   ├── styles/main.css
│   └── scripts/main.js
├── capabilities/             # Draft format for reusable AI capabilities
│   └── example-capability.json
├── docs/                     # Project notes and planning
├── CONTRIBUTING.md
└── README.md
```

## Running the MVP locally

No dependencies or build step are required.

Option 1: open `src/index.html` directly in a browser.

Option 2: serve the folder locally (recommended, so the fonts and scripts load consistently):

```bash
cd src
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Roadmap (planned)

- [x] Landing page MVP
- [ ] Capability format specification (draft in `capabilities/`)
- [ ] Capability validator (CLI)
- [ ] Local agent runner for defined tasks
- [ ] Permissions and licensing model
- [ ] Collaboration and revenue-sharing model

## License

To be announced. A license will be chosen and added to this repository before the first public release.

## Contact

Placeholder address: `hello@delance.ai`. Replace before publishing.
